import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.EmptySource;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.List;
import java.util.stream.Stream;

import static org.assertj.core.api.Assertions.*;

@DisplayName("컴퓨터는 랜덤값을 받습니다.")
public class ComputerTest {
    Computer computer = Computer.create();

    @Test
    void createComputer(){
        assertThatCode(() ->{
            Computer computer = Computer.create();
        }).doesNotThrowAnyException();
    }

    @ParameterizedTest
    @MethodSource(value = "computerValues")
    void computerValues(List<Integer> values){
        computer.setRandomValues(values);
        assertThat(computer.getValues().size()).isEqualTo(3);
    }

    @ParameterizedTest
    @EmptySource
    void computerValuesWithEmptyValue(List<Integer> values){
        assertThatThrownBy(() -> {
            computer.setRandomValues(values);
        }).isInstanceOf(IllegalArgumentException.class);

    }
    static Stream<Arguments> computerValues(){
        return Stream.of(
                Arguments.of(List.of(1,2,3)),
                Arguments.of(List.of(1,4,5)),
                Arguments.of(List.of(1,6,4)));
    }
}
