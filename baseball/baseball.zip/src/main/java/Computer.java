import java.util.ArrayList;
import java.util.List;

public class Computer {

    private List<Integer> values = new ArrayList<>(3);

    public static Computer create() {
        return new Computer();
    }

    public void setRandomValues(List<Integer> values) {
        if (values.isEmpty()){
            throw new IllegalArgumentException("VALUES IS EMPTY");
        }
        this.values = values;
    }

    public List<Integer> getValues() {
        return values;
    }
}
