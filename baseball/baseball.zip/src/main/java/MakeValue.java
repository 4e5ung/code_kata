import java.util.List;

public interface MakeValue {
    List<Integer> makeRandomValue();
}
